# Go GRPC Example

本项目提供[Go-gRPC 实践指南](https://github.com/jergoo/go-grpc-practice-guide)项目中的示例代码。

segmentfault连载的 **Golang gRPC实践** 系列文章中的示例也包含在本项目中，文章暂时没有同步更新，代码以本项目为准。

* [Golang gRPC实践 连载一 gRPC介绍与安装](https://segmentfault.com/a/1190000007880647)
* [Golang gRPC实践 连载二 Hello gRPC](https://segmentfault.com/a/1190000007909829)
* [Golang gRPC实践 连载三 Protobuf语法](https://segmentfault.com/a/1190000007917576)
* [Golang gRPC实践 连载四 gRPC认证](https://segmentfault.com/a/1190000007933303)
* [Golang gRPC实践 连载五 拦截器 Interceptor](https://segmentfault.com/a/1190000007997759)
* [Golang gRPC实践 连载六 内置Trace](https://segmentfault.com/a/1190000008087436)  
* [Golang gRPC实践 连载七 http转换](https://segmentfault.com/a/1190000008106582)
